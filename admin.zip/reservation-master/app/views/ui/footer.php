
<!-- jQuery  -->
<script src="<?php echo THEME; ?>js/jquery.min.js"></script>

<script src="<?php echo THEME; ?>assets/daterangepicker/moment.min.js"></script>

<script src="<?php echo THEME; ?>js/bootstrap.min.js"></script>
<script src="<?php echo THEME; ?>js/waves.js"></script>
<script src="<?php echo THEME; ?>js/wow.min.js"></script>
<script src="<?php echo THEME; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="<?php echo THEME; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo THEME; ?>assets/jquery-detectmobile/detect.js"></script>
<script src="<?php echo THEME; ?>assets/fastclick/fastclick.js"></script>
<script src="<?php echo THEME; ?>assets/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="<?php echo THEME; ?>assets/jquery-blockui/jquery.blockUI.js"></script>

<script src="<?php echo THEME; ?>assets/jQuery-Mask-Plugin/jquery.mask.min.js"></script>

<script src="<?php echo THEME; ?>assets/sweet-alert/sweet-alert.min.js"></script>

<!-- <script src="http://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.js"></script> -->
<!-- <script src="http://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script> -->
<!-- CUSTOM JS -->


<!-- DATE PICKER -->
<script src="<?php echo THEME; ?>assets/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo THEME; ?>assets/timepicker/bootstrap-datepicker.js"></script>

<!-- Modal-Effect -->
<script src="<?php echo THEME; ?>assets/modal-effect/js/classie.js"></script>
<script src="<?php echo THEME; ?>assets/modal-effect/js/modalEffects.js"></script>


<!-- Page Specific JS Libraries -->
<script src="<?php echo THEME; ?>assets/dropzone/dropzone.min.js"></script>

<!-- CHART JS -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.js"></script> -->


<script src="<?php echo THEME; ?>js/jquery.app.js"></script>
<!-- CUSTOM JS -->


<script src="<?php echo THEME; ?>assets/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo THEME; ?>assets/datatables/dataTables.bootstrap.js"></script>

<script src="<?php echo THEME; ?>assets/print.js"></script>

<script src="<?php echo THEME; ?>assets/summernote/summernote.min.js"></script>
<script src="<?php echo THEME; ?>assets/datepicker/bootstrap-datepicker.js"></script>

<script src="<?php echo THEME; ?>assets/daterangepicker/daterangepicker.js"></script>

<script src="<?php echo THEME; ?>assets/select2/select2.full.min.js"></script>

<script src="<?php echo THEME; ?>assets/toastr/toastr.min.js"></script>
<script src="<?php echo THEME; ?>assets/overlay_loading/loadingoverlay.min.js"></script>

<script src="<?php echo THEME; ?>assets/jquery-timepicker/jquery.timepicker.min.js"></script>



<script src="<?php echo THEME; ?>js/custom.js"></script>
<script src="<?php echo THEME; ?>js/coms.js"></script>

